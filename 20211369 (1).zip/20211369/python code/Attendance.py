import Utils as ut
import Db as db
import Main as ma



# display the attendance menu
def display_attendance_menu():
    ut.cls()
    ut.print_banner("ATTENDANCE MENU")
    print()
    ut.print_menu_options(["VIEW ATTENDANCE OF STUDENT(S)",
                           "MARK ATTENDANCE",
                           "BACK TO MAIN MENU",
                           "EXIT"])
    option = input("Please Select an option to Continue:")
    if option == "1":
        view_student_attendance()
    elif option == "2":
        mark_attendance()
    elif option == "3":
        ma.display_main_menu()
    elif option == "4":
        exit(0)


# mark the attendance(present or absent)
def mark_attendance():
    ut.cls()
    ut.print_banner("ATTENDANCE MARKING")
    print("Enter the date for Attendance Marking in DD_MMM_YYYY Format (i.e 05_AUG_2022)")
    date = ut.get_date()
    columnsList = db.get_list_of_columns_from_attendance_table()
    if date not in columnsList: db.add_new_column_to_attendance_table(date)
    studentsList = [i[0] for i in db.view_attendance_of_student("*", False)]
    present, absent = get_attendance_from_user(studentsList)
    db.update_attendance_in_table(date, present, "P")
    db.update_attendance_in_table(date, absent, "A")
    db.view_attendance_of_student("*")
    ut.display_end_menu()


# view the attendance table
def view_student_attendance():
    ut.cls()
    ut.print_banner("VIEW ATTENDANCE INFORMATION")
    print("Enter Student Id to Select a Student's Attendance Or * View All Students Attendance")
    # studentId = input("Student Id :")
    studentId = ut.get_valid_student_id()
    if (len(db.get_student_by_id_from_db(studentId,False)) == 0):
         print("Student Id:", studentId, "Missing in Database")
    db.view_attendance_of_student(studentId)
    ut.display_end_menu()


# get the attendance from user for student in the attendance table
def get_attendance_from_user(studentsList):
    present = []
    absent = []
    ut.print_line("-", ut.SCREEN_LEN)
    print("Enter 'P' to Mark as Present and 'A' to Mark as absent")
    for studentId in studentsList:
        attendance = ut.get_attendance_input(studentId)
        if attendance.upper() == "P":
            present.append(studentId)
        elif attendance.upper() == "A":
            absent.append(studentId)
        else:
            print("invalid input")
    return present, absent
