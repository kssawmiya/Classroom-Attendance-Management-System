import os
import time
import Main as ma
import Db as db
import re
from prettytable import PrettyTable as pt

SCREEN_LEN = 83
OPTION_SELECT_MESSAGE = "Choose one of the Option to Continue:"


# create the symbol in single line
def print_line(symbol, count):
    line = ""
    for i in range(count):
        line += symbol
    print(line)


# create the banner
def print_banner(text):
    print_line("*", SCREEN_LEN)
    print_center(text, SCREEN_LEN)
    print_line("*", SCREEN_LEN)


# print the text in center
def print_center(text, SCREEN_LEN):
    print(text.center(SCREEN_LEN, " "))


# print menu options
def print_menu_options(menu):
    line = ""
    for i in range(len(menu)):
        line += str(i + 1) + ". " + menu[i].upper()
        line += "\n"
    print(line)


# clear the previous screen
def cls():
    time.sleep(0.25)
    os.system('cls' if os.name == 'nt' else 'clear')


# print the table
def display_table(title, columnNames, data):
    tb = pt(columnNames, title=title)
    for x in data:
        tb.add_row(list(x))
    if(len(data)>0):
        print(tb)


# the user input is "1",back to the main menu or the user input is "2",exit the program
def display_end_menu():
    print_menu_options(["BACK TO MAIN MENU", "EXIT"])
    option = input(OPTION_SELECT_MESSAGE)
    if option == "1":
        ma.display_main_menu()
    elif option == "2":
        exit(0)


# get the input from user
def get_input(prompt=OPTION_SELECT_MESSAGE, cast=None, condition=None, errorMessage=None):
    while True:
        try:
            rawInput = input(prompt)
            response = (cast or str)(rawInput)
            assert condition is None or condition(response)
            return response
        except:
            print(errorMessage.format(rawInput), ", Please try Again!")


# get the date from user
def get_date():
    pat = re.compile(r"^(([0-2][0-9])|([3][0-1]))\_(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)\_\d{4}$")
    while True:
        date = input("Date: ").upper()
        if re.fullmatch(pat, date):
            return date
        else:
            print("Invalid date", date, ",Date has to be in format DD_MMM_YYYY,please try again!!!")


# get validation attendance input
def get_attendance_input(studentId):
    while True:
        attendance = input("Is Student Id: " + str(studentId) + " is present:").upper()
        if attendance == "A" or attendance == "P":
            return attendance
        else:
            print("Invalid Input,please try again")


def get_valid_student_id():
    while True:
        try:
            studentId = input("Student Id:")
            if (studentId == "*"):
                return studentId
            else:
                return int(studentId)
        except:
            print("Invalid Student Id", studentId, "Please Try Again!!")


# initialized the data base
def init():
    db.database_setup("setup.sql")
    cls()
