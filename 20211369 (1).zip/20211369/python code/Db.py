import mysql.connector
import Utils as ut

connection = None

# open the data base
def get_db_connection():
    global connection
    if not connection:
        connection = mysql.connector.connect(host="localhost", user="root", database="student")
    return connection

# Fetch result using fetchall() method from database
def fetch_results_from_db(sql, cursor, parameters=None):
    if parameters is None:
        cursor.execute(sql)
    else:
        cursor.execute(sql, parameters)
    return cursor.fetchall()

# execute SQL query using execute() method
def execute_sql(sql, con, parameters=None):
    cursor = con.cursor()
    if parameters is None:
        cursor.execute(sql)
    else:
        cursor.execute(sql, parameters)
    con.commit()
    return cursor.rowcount


# view the student table in the database
def get_student_by_id_from_db(studentId,display=True):
    studentId=str(studentId)
    sql = "SELECT * FROM Student "
    title = "STUDENT INFORMATION"
    if studentId != "*":
        sql += "WHERE StudentId=" + studentId
        title += " OF ID " + studentId
    result = fetch_results_from_db(sql, get_db_connection().cursor())
    if(display):ut.display_table(title, ["STUDENT ID", "FIRST NAME", "LAST NAME", "EMAIL", "AGE"], result)
    return result


# update the student information in the student table at database
def update_student_info_in_db(data, studentId):
    sql = "UPDATE Student SET LastName=%s,FirstName=%s, Email=%s, Age=%s WHERE StudentId=%s ;"
    rowsEffected = execute_sql(sql, get_db_connection(),
                               (data["LAST NAME"], data["FIRST NAME"], data["EMAIL"], data["AGE"], studentId))
    return rowsEffected

# add the student information in the student table at database
def add_student_info_to_db(data):
    studentId = None
    sql = "INSERT INTO Student (LastName,FirstName,Email,Age) VALUES (%s,%s,%s,%s) ;"
    rowsEffected = execute_sql(sql, get_db_connection(),
                               (data["LAST NAME"], data["FIRST NAME"], data["EMAIL"], data["AGE"]))
    if (rowsEffected > 0):
        sql = "SELECT StudentId FROM Student ORDER BY StudentId DESC LIMIT 1 "
        studentId = str(fetch_results_from_db(sql, get_db_connection().cursor())[0][0])
    else:
        print("Error Occurred while Inserting the Data to Student Table")
    return studentId

# delete the student information in student table at database
def delete_student_info(studentId):
    sql = "DELETE FROM Student where StudentId=%s"
    rowsEffected = execute_sql(sql, get_db_connection(), [studentId])
    return rowsEffected

# enroll the studentId in the attendance table at batabase
def enrol_student_to_attendance_table(studentId):
    sql = "INSERT INTO Attendance (StudentId) VALUES (%s) ;"
    rowsEffected = execute_sql(sql, get_db_connection(), [int(studentId)])
    if rowsEffected > 0:
        print("StudentId " + studentId + " Enrolled to Attendance Table Successfully")
    else:
        print("Error in Enrolling the StudentId " + studentId)

# delete the studentId in attendance table at database
def un_enrol_student_to_attendance_table(studentId):
    sql = "DELETE FROM Attendance WHERE StudentId=%s ;"
    rowsEffected = execute_sql(sql, get_db_connection(), [int(studentId)])
    if rowsEffected > 0:
        print("StudentId " + str(studentId) + " UnEnrolled From Attendance Table Successfully")
    else:
        print("Error in UnEnrolling the StudentId " + studentId)

# get list of columns from attendance table
def get_list_of_columns_from_attendance_table():
    columnSql = "SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='student' AND `TABLE_NAME`='Attendance';"
    columnsList = [i[0] for i in fetch_results_from_db(columnSql, get_db_connection().cursor())]
    return columnsList

# add a new colum in attendance table
def add_new_column_to_attendance_table(date):
    sql = "ALTER TABLE Attendance ADD " + date + " varchar(1);"
    execute_sql(sql, get_db_connection())


# view the attendance table at database
def view_attendance_of_student(studentId, display=True):
    studentId = str(studentId)
    sql = "SELECT * FROM Attendance "

    title = "ATTENDANCE INFORMATION"
    if studentId != "*":
        sql += "WHERE StudentId=" + studentId
        title += " OF ID " + studentId
    result = fetch_results_from_db(sql, get_db_connection().cursor())
    columnsList = get_list_of_columns_from_attendance_table()
    columnsList[0] = "STUDENT ID"
    if display: ut.display_table(title, columnsList, result)
    return result

# update the attendance table in database
def update_attendance_in_table(date, studentList, status):
    if len(studentList) > 0:
        sql = "UPDATE Attendance SET " + date + "='" + status + "' WHERE StudentId IN (%s) ;"
        format_strings = ','.join(['%s'] * len(studentList))
        execute_sql(sql % format_strings, get_db_connection(), studentList)

# initialized the database with setup.sql file
def database_setup(fileName):
    with open(fileName, 'r') as sql_file:
        con = mysql.connector.connect(host="localhost", user="root")
        cur = con.cursor()
        result_iterator = cur.execute(sql_file.read(), multi=True)
        print("Initializing the Database...")
        try:
            for res in result_iterator:
                print("Running query: ", res)
                print(f"Affected {res.rowcount} rows")
            get_db_connection().commit()
        except:
            print("execption occured in db")
        finally:
            con.close()
