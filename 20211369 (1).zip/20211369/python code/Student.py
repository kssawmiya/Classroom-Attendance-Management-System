import Utils as ut
import Db as db
import Main as ma


# display student menu
def display_student_menu():
    ut.cls()
    ut.print_banner("STUDENT MENU")
    print()
    ut.print_menu_options(["VIEW CURRENT STUDENT(S)",
                           "UPDATE A STUDENT'S INFORMATION",
                           "ADD NEW STUDENT",
                           "DELETE A STUDENT",
                           "BACK TO MAIN",
                           "EXIT"])
    option = ut.get_input(
        cast=int,
        condition=lambda x: 1 <= x <= 6,
        errorMessage="The provided option {0} is Invalid, It has to be an integer in range [1,6]"
    )
    if option == 1:
        view_students()
    elif option == 2:
        update_student()
    elif option == 3:
        add_new_student()
    elif option == 4:
        delete_student()
    elif option == 5:
        ma.display_main_menu()
    elif option == 6:
        exit(0)


# view the student table
def view_students():
    ut.cls()
    ut.print_banner("VIEW CURRENT STUDENT(S)")
    print("Enter Student Id to Select a Student Or * View All the Students")
    studentId = ut.get_valid_student_id()
    if(len(db.get_student_by_id_from_db(studentId))==0):
        print("Student Id:",studentId,"Missing in Database")
    ut.display_end_menu()


# update  the student table
def update_student():
    ut.cls()
    ut.print_banner("UPDATE STUDENT INFORMATION")
    print("Enter StudentId to Update Information")
    # studentId = input("Student Id :")
    studentId = ut.get_input(
        prompt="Student Id :",
        cast=int,
        condition=lambda x: x > 0,
        errorMessage="The provided studentId {0} is Invalid, It has to be an integer greater than zero"
    )
    if (len(db.get_student_by_id_from_db(studentId)) != 0):
        data = get_student_info_from_user(["FIRST NAME", "LAST NAME", "EMAIL", "AGE"])
        ut.cls()
        ut.print_banner("UPDATE STUDENT INFORMATION")
        if db.update_student_info_in_db(data, studentId) > 0:
            print("Data Updated Successfully for StudentId:" + str(studentId))
            db.get_student_by_id_from_db(studentId)
        else:
            print("Error Occurred While Updating the data for StudentId:" + studentId)
        ut.display_end_menu()
    else:
        print("Student Id:",studentId,"Missing in Database!!")
        ut.display_end_menu()

# add new student information in a student table
def add_new_student():
    ut.cls()
    ut.print_banner("ADD NEW STUDENT INFORMATION")
    data = get_student_info_from_user(["FIRST NAME", "LAST NAME", "EMAIL", "AGE"], "INSERT")
    ut.cls()
    ut.print_banner("ADD NEW STUDENT INFORMATION")
    studentId = db.add_student_info_to_db(data)
    if studentId is not None:
        print("Data Successfully Inserted for StudentId:" + str(studentId))
        db.enrol_student_to_attendance_table(studentId)
        db.get_student_by_id_from_db(studentId)
    else:
        print("Error Occurred While Updating the data for StudentId:" + str(studentId))
    ut.display_end_menu()


# get the input for the different colum in the student table from the user
def get_student_info_from_user(columns, task="UPDATE"):
    studentData = {}
    print("Please Enter the Following Info to " + task + ":")
    ut.print_line("-", ut.SCREEN_LEN)
    for col in columns:
        userData = input(col + ":")
        studentData.update({col: userData})
    return studentData


# delete the student information in the student table
def delete_student():
    ut.cls()
    ut.print_banner("DELETE STUDENT INFORMATION")
    print("Enter Student Id to to DELETE from Student Table")
    db.get_student_by_id_from_db("*")
    studentId = ut.get_input(
        prompt="Student Id :",
        cast=int,
        condition=lambda x: x > 0,
        errorMessage="The provided studentId {0} is Invalid, It has to be an integer greater than zero"
    )
    ut.cls()
    ut.print_banner("DELETE STUDENT INFORMATION")
    if db.delete_student_info(studentId) > 0:
        print("Data Successfully Deleted for StudentId:" + str(studentId))
        db.un_enrol_student_to_attendance_table(studentId)
        db.get_student_by_id_from_db("*")
    else:
        print("Error Occurred While Deleting the data for StudentId:" + str(studentId))
    ut.display_end_menu()
