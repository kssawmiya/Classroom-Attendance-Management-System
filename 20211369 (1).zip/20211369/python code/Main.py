import Utils as ut
import Student as st
import Attendance as at

# display main menu
def display_main_menu(clear=True):
    # clear the screen
    if clear:
        ut.cls()

    # print banner with title MAIN MENU
    ut.print_banner("MAIN MENU")
    print()

    # print main menu options
    ut.print_menu_options(["STUDENT MENU", "ATTENDANCE MENU", "EXIT"])

    # get the input from the user select the menu option
    option = ut.get_input(
        cast=int,
        condition=lambda x: 1 <= x <= 3,
        errorMessage="The provided option {0} is Invalid, It has to be an integer in range [1,3]"
    )

    # the user input option equal to "1",display student menu
    if option == 1:
        st.display_student_menu()

    # the user input option equal to "2",display attendance menu
    elif option == 2:
        at.display_attendance_menu()

    # the user input option equal to "3",exit the program
    elif option == 3:
        exit(0)
