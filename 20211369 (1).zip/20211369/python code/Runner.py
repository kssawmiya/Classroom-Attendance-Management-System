import Utils as ut
from pyfiglet import figlet_format
import Main as ma

# initialized data base
ut.init()

# print ASCII design
print(figlet_format("IIT STUDENT ATTENDANCE", font="slant"))

# call the display main menu
ma.display_main_menu(False)
