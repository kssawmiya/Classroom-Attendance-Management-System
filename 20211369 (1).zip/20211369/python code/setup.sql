CREATE DATABASE IF NOT EXISTS  student;

DROP TABLE IF EXISTS student.Student;
DROP TABLE IF EXISTS student.Attendance;

CREATE TABLE student.Student (
       StudentId int NOT NULL AUTO_INCREMENT,
       FirstName varchar(50) DEFAULT NULL,
       LastName varchar(50) DEFAULT NULL,
       Email varchar(50) DEFAULT NULL,
       Age int DEFAULT NULL,
       PRIMARY KEY (StudentId)
) ;


CREATE TABLE student.Attendance (
      StudentId int NOT NULL,
      22_AUG_2022 varchar(1) DEFAULT NULL,
      23_AUG_2022 varchar(1) DEFAULT NULL,
      PRIMARY KEY (StudentId)
);

INSERT  INTO student.Student (StudentId, LastName, FirstName, Email, Age) VALUES(1, 'Suwathi', 'Sawmiya', 'suwathi123@gamil.com', 18);
INSERT  INTO student.Student (StudentId, LastName, FirstName, Email, Age) VALUES(2, 'abirami', 'amu', 'amu.abi@gmail.com', 15);
INSERT  INTO student.Student (StudentId, LastName, FirstName, Email, Age) VALUES(3, 'patel', 'anu', 'anu.p@gmail.com', 12);

INSERT  INTO student.Attendance (StudentId, 22_AUG_2022, 23_AUG_2022 ) VALUES(1, 'P', 'A');
INSERT  INTO student.Attendance (StudentId, 22_AUG_2022, 23_AUG_2022) VALUES(2, 'A', 'P');
INSERT  INTO student.Attendance (StudentId, 22_AUG_2022, 23_AUG_2022) VALUES(3, 'P', 'A');

COMMIT ;

